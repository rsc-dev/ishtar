import clr
clr.AddReferenceToFile('ObjectUtils.dll')
import ObjectUtils
print '[+] Added ObjectUtils'
